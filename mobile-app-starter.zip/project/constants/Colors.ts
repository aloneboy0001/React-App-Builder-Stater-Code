const tintColorLight = '#007AFF';
const tintColorDark = '#0A84FF';

export default {
  light: {
    text: '#000000',
    background: '#FFFFFF',
    tint: tintColorLight,
    tabIconDefault: '#8E8E93',
    tabIconSelected: tintColorLight,
    border: '#E5E5EA',
    notification: '#FF3B30',
    card: '#FFFFFF',
    shadow: 'rgba(0, 0, 0, 0.1)',
  },
  dark: {
    text: '#FFFFFF',
    background: '#000000',
    tint: tintColorDark,
    tabIconDefault: '#8E8E93',
    tabIconSelected: tintColorDark,
    border: '#38383A',
    notification: '#FF453A',
    card: '#1C1C1E',
    shadow: 'rgba(255, 255, 255, 0.1)',
  },
};